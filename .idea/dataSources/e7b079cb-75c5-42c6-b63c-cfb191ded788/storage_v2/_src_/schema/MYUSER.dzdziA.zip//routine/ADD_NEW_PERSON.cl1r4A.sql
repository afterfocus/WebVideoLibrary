CREATE FUNCTION add_new_person (
    surname       VARCHAR2,
    name          VARCHAR2,
    phonenumber   VARCHAR2
)
    RETURN INTEGER
    IS
    person_id INTEGER;
BEGIN
    person_id := person_id_sequence.NEXTVAL;
    INSERT INTO person VALUES (
        person_id,
        surname,
        name,
        phonenumber
    );
    COMMIT;
    RETURN person_id;
END add_new_person;
/

