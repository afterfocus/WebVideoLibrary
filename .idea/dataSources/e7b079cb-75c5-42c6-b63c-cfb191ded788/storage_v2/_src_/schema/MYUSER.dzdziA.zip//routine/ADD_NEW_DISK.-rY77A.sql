CREATE FUNCTION add_new_disk (
    rus_title      IN VARCHAR2,
    eng_title      IN VARCHAR2,
    release_year   IN INTEGER,
    person_id      IN INTEGER
)
    RETURN INTEGER
    IS
    disk_id INTEGER;
BEGIN
    disk_id := disk_id_sequence.nextval;
    IF person_id != 0 THEN
    INSERT INTO disk VALUES (
        disk_id,
        rus_title,
        eng_title,
        release_year,
        person_id
    );
    ELSE
        INSERT INTO disk VALUES (
        disk_id,
        rus_title,
        eng_title,
        release_year,
        NULL
    );
    END IF;
    COMMIT;
    RETURN disk_id;

END add_new_disk;
/

